# VERITAS v5.0 — Unified Entry Deployment

## 🎯 What This Deploy Does

This update integrates **Track B (Understand & Explore)** into the existing VERITAS platform via a **Classification Modal** that routes users to the appropriate track:

- **Track A** — Factual verification (existing assess functionality)
- **Track B Standard** — Conversational exploration of contested beliefs
- **Track B Armor** — For weaponized communication patterns
- **Track B Mirror** — For users who are correct but contemptuous

## 📁 Files to Deploy

### Frontend (root directory)
| File | Action | Notes |
|------|--------|-------|
| `assess.html` | **REPLACE** | Now unified entry point with classification modal |
| `conversation.html` | **NEW** | Track B chat interface |
| `conversation.css` | **NEW** | Track B styling |
| `conversation.js` | **NEW** | Track B client-side logic |

### API (api/ directory)
| File | Action | Notes |
|------|--------|-------|
| `api/classify.js` | **NEW** | Classification Inquiry endpoint |
| `api/conversation.js` | **NEW** | Track B conversation engine |

## 🚀 Deployment Steps

### 1. Add Files to GitHub Repository

```bash
# Clone your repo (if not already)
git clone https://github.com/rauelsky/veritastruth.net.git
cd veritastruth.net

# Copy files from this package
# REPLACE assess.html in root
# ADD conversation.html, conversation.css, conversation.js to root
# ADD classify.js, conversation.js to api/ folder

git add .
git commit -m "Add Track B with Classification Modal - v5.0"
git push origin main
```

### 2. Verify Vercel Environment

Ensure `ANTHROPIC_API_KEY` is set in your Vercel project settings:
- Go to: Vercel Dashboard → Project Settings → Environment Variables
- Confirm `ANTHROPIC_API_KEY` exists and is valid

### 3. Vercel Auto-Deploy

Vercel should automatically deploy when you push to main. Monitor the deployment at:
- https://vercel.com/[your-username]/veritastruth-net

### 4. Test the Deployment

1. **Visit** `https://veritastruth.net/assess` (or your domain)
2. **Enter a test claim** — try these:
   - Factual: "Did Trump say windmills cause cancer?"
   - Contested: "Should assault weapons be banned?"
   - Contemptuous: "How can anyone believe the election was stolen?"
3. **Click "Begin"** — the Classification Modal should appear
4. **Verify routing:**
   - Factual claims → Track A (stay on page)
   - Normative/contested → Track B (redirect to conversation.html)
5. **Test Track B conversation** — ensure responses come through

## 🔧 Troubleshooting

### Classification API not working
- Check Vercel function logs for errors
- Verify `ANTHROPIC_API_KEY` is set
- Test endpoint directly: `POST /api/classify` with `{"input": "test claim"}`

### Conversation not loading
- Verify `conversation.html`, `conversation.js`, `conversation.css` are deployed
- Check browser console for errors
- Test endpoint: `POST /api/conversation` with `{"messages": [{"role":"user","content":"test"}]}`

### Mode not being passed
- Check URL parameters: `conversation.html?q=...&mode=armor`
- Verify `conversation.js` is the updated version with mode handling

## 📊 What to Watch For

After deployment, monitor:
1. **Classification accuracy** — Is it routing correctly?
2. **Track B conversation quality** — Is VERITAS embodying the protocol?
3. **User flow** — Do users understand the choice they're making?
4. **Performance** — Are API calls completing in reasonable time?

## 🔜 Next Steps After Testing

1. **Refine system prompts** based on real conversations
2. **Add analytics events** for tracking usage patterns
3. **Cross-track handoffs** (Track A → B and B → A)
4. **Update index.html** with Track B information

---

## Files Structure After Deployment

```
veritastruth.net/
├── api/
│   ├── assess.js           (existing)
│   ├── classify.js          (NEW)
│   └── conversation.js      (NEW)
├── index.html               (existing - update later)
├── assess.html              (REPLACED - now unified entry)
├── conversation.html        (NEW)
├── conversation.js          (NEW)
├── conversation.css         (NEW)
└── ... (other existing files)
```

---

*Deployment Package Created: December 22, 2025*
*Version: 5.0 — Unified Entry with Classification Modal*

🖖
