/**
 * VERACITY v5.2 — TRACK A STREAMING: ASSESS-STREAM API
 * =====================================================
 * Vercel Serverless Function
 * 
 * Endpoint: /api/assess-stream
 * Method: POST
 * 
 * Streaming version of the assess endpoint using Server-Sent Events.
 * Provides progressive updates as Claude generates the assessment.
 * 
 * Events emitted:
 *   - status: Progress updates (searching, analyzing, etc.)
 *   - chunk: Incremental text content
 *   - section: Complete section data
 *   - score: Reality/Integrity scores (may be provisional)
 *   - error: Error notifications
 *   - complete: Stream finished
 */

const { EventEmitter, setupSSEHeaders, getStatusMessage, StreamParser } = require('../modules/streaming');

// Import VINCULUM for language support (adjust path as needed)
// const { LANGUAGE_CONFIG, buildAssessLanguageInstruction } = require('../modules/vinculum');

export const config = {
    // Disable body parsing for streaming
    api: {
        bodyParser: true
    },
    // Extend timeout for streaming
    maxDuration: 60
};

export default async function handler(req, res) {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
        return res.status(200).end();
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    // Set up SSE headers
    setupSSEHeaders(res);

    // Create event emitter
    const emitter = new EventEmitter(res);
    const parser = new StreamParser();
    const startTime = Date.now();

    try {
        const { 
            query, 
            assessmentType = 'full',
            language = 'en'
        } = req.body;

        if (!query) {
            emitter.error('MISSING_QUERY', 'Query is required');
            emitter.complete({ success: false });
            return res.end();
        }

        // Get API key
        const apiKey = process.env.VERITAS_DEV || process.env.VERITAS_PROD;
        if (!apiKey) {
            emitter.error('CONFIG_ERROR', 'API key not configured');
            emitter.complete({ success: false });
            return res.end();
        }

        // Emit initial status
        emitter.status('connecting', getStatusMessage('connecting', language), 0.05);

        // Build system prompt (simplified version - full version would import from assess.js)
        const systemPrompt = buildSystemPrompt(assessmentType, language);

        // Start streaming request to Claude
        emitter.status('analyzing', getStatusMessage('analyzing', language), 0.1);

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 8192,
                stream: true, // Enable streaming
                system: systemPrompt,
                tools: [
                    {
                        type: "web_search_20250305",
                        name: "web_search",
                        max_uses: 10
                    }
                ],
                messages: [
                    { role: 'user', content: query }
                ]
            })
        });

        if (!response.ok) {
            const error = await response.json();
            emitter.error('API_ERROR', error.error?.message || 'API request failed');
            emitter.complete({ success: false });
            return res.end();
        }

        // Process the stream
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let totalTokens = 0;
        let searchCount = 0;

        emitter.status('searching', getStatusMessage('searching', language), 0.2);

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            
            // Parse SSE events from Claude's stream
            const lines = chunk.split('\n');
            
            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                
                const data = line.slice(6);
                if (data === '[DONE]') continue;

                try {
                    const event = JSON.parse(data);
                    
                    // Handle different Claude stream event types
                    switch (event.type) {
                        case 'message_start':
                            // Message started
                            break;
                            
                        case 'content_block_start':
                            if (event.content_block?.type === 'tool_use') {
                                searchCount++;
                                emitter.status(
                                    'searching', 
                                    `${getStatusMessage('searching', language)} (${searchCount})`,
                                    0.2 + (searchCount * 0.05)
                                );
                            }
                            break;
                            
                        case 'content_block_delta':
                            if (event.delta?.type === 'text_delta') {
                                const text = event.delta.text;
                                
                                // Feed to parser
                                const events = parser.process(text);
                                
                                // Emit any extracted events
                                for (const evt of events) {
                                    if (evt.type === 'score') {
                                        emitter.score(
                                            evt.realityScore, 
                                            evt.integrityScore, 
                                            evt.provisional
                                        );
                                        emitter.status(
                                            'evaluating',
                                            getStatusMessage('evaluating', language),
                                            0.6
                                        );
                                    } else if (evt.type === 'section') {
                                        emitter.section(evt.name, evt.content, evt.final);
                                    }
                                }
                                
                                // Emit raw chunk for progressive display
                                emitter.chunk('text', text, false);
                            }
                            break;
                            
                        case 'message_delta':
                            if (event.usage) {
                                totalTokens = (event.usage.input_tokens || 0) + 
                                             (event.usage.output_tokens || 0);
                            }
                            break;
                            
                        case 'message_stop':
                            // Message complete
                            break;
                    }
                } catch (parseError) {
                    // Skip malformed events
                    console.error('Stream parse error:', parseError.message);
                }
            }
        }

        // Finalize parsing
        emitter.status('synthesizing', getStatusMessage('synthesizing', language), 0.9);
        
        const finalResult = parser.finalize();
        if (finalResult) {
            // Emit final scores (non-provisional)
            if (finalResult.realityScore !== undefined) {
                emitter.score(
                    finalResult.realityScore,
                    finalResult.integrityScore,
                    false
                );
            }
            
            // Emit any remaining sections
            for (const [name, content] of Object.entries(finalResult)) {
                if (name !== 'realityScore' && name !== 'integrityScore') {
                    emitter.section(name, content, true);
                }
            }
        }

        // Calculate duration and complete
        const duration = (Date.now() - startTime) / 1000;
        
        emitter.status('complete', getStatusMessage('complete', language), 1.0);
        emitter.complete({
            success: true,
            totalTokens,
            duration
        });

    } catch (error) {
        console.error('Assess-stream error:', error);
        emitter.error('INTERNAL_ERROR', error.message || 'Internal server error');
        emitter.complete({ success: false });
    }

    res.end();
}

/**
 * Build system prompt for streaming assessment
 * (Simplified version - full implementation would import from assess.js)
 */
function buildSystemPrompt(assessmentType, language) {
    // This is a minimal version - full version imports from assess.js
    return `You are VERITAS, a sophisticated claim assessment system.

Analyze the user's query and provide a structured assessment with:
- realityScore: -10 (completely false) to +10 (definitively true)
- integrityScore: -1 (manipulative) to +1 (honest presentation)
- underlyingReality: The actual truth of the matter
- evidenceSummary: Key evidence found
- confidenceStatement: Your confidence level and reasoning

Use web search to verify current facts. Be thorough but concise.

Respond in valid JSON format.`;
}
