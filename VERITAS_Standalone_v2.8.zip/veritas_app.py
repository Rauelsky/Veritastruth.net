"""
VERITAS Assessment Tool v2.8
Truth through Transparency

Separate Reality Score and Integrity Score - No Multiplication
Two independent measurements with warning flag system
"""

from flask import Flask, render_template, request, jsonify
import anthropic
import os
import json
from datetime import datetime

app = Flask(__name__)

# Configuration file paths
CONFIG_FILE = os.path.join(os.path.expanduser('~'), 'VERITAS_Data', 'config.json')
USAGE_FILE = os.path.join(os.path.expanduser('~'), 'VERITAS_Data', 'usage.json')

def load_config():
    """Load API key from config file"""
    try:
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
            return config.get('api_key', '')
    except:
        return ''

def save_config(api_key):
    """Save API key to config file"""
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'api_key': api_key}, f)

def load_usage():
    """Load usage data"""
    try:
        with open(USAGE_FILE, 'r') as f:
            return json.load(f)
    except:
        return {'count': 0, 'month': datetime.now().strftime('%Y-%m'), 'history': []}

def save_usage(usage_data):
    """Save usage data"""
    os.makedirs(os.path.dirname(USAGE_FILE), exist_ok=True)
    with open(USAGE_FILE, 'w') as f:
        json.dump(usage_data, f, indent=2)

def increment_usage():
    """Increment usage counter and return current count"""
    usage = load_usage()
    current_month = datetime.now().strftime('%Y-%m')
    
    # Reset counter if new month
    if usage.get('month') != current_month:
        usage = {'count': 0, 'month': current_month, 'history': usage.get('history', [])}
    
    usage['count'] += 1
    usage['history'].append({
        'timestamp': datetime.now().isoformat(),
        'month': current_month
    })
    
    save_usage(usage)
    return usage['count']

# ============================================================
# PROMPTS - DUAL INDEPENDENT SCORING SYSTEM
# ============================================================

def get_article_assessment_prompt(url, article_text):
    """Generate the assessment prompt for article mode with SEPARATE scores"""
    return f"""You are VERITAS, an evidence-based article assessment system.

ARTICLE URL: {url}
ARTICLE TEXT:
{article_text[:8000]}

=== CRITICAL: TWO INDEPENDENT MEASUREMENTS ===

You must provide TWO SEPARATE scores that answer TWO DIFFERENT questions:

1. **REALITY SCORE** (-10 to +10): Are the article's CLAIMS factually true or false?
   This measures correspondence with reality.

2. **INTEGRITY SCORE** (-1.0 to +1.0): Is the SOURCE operating honestly?
   This measures whether the article presents information with epistemological integrity,
   regardless of whether its claims are true.

THESE ARE INDEPENDENT. An article can be:
- TRUE (+7) and HONEST (+0.8) — Good journalism
- TRUE (+7) and DISHONEST (-0.3) — Propaganda that happens to be factual
- FALSE (-6) and HONEST (+0.5) — Sincere error
- FALSE (-6) and DISHONEST (-0.7) — Deliberate disinformation

DO NOT multiply these scores. Report them separately.

=== RESPONSE FORMAT ===

# REALITY SCORE: [number from -10 to +10]
(Are the central claims TRUE or FALSE?)

# INTEGRITY SCORE: [number from -1.0 to +1.0]
(Is the source operating HONESTLY or DISHONESTLY?)

## The Underlying Truth
[What is ACTUALLY TRUE about this subject, independent of how this article frames it?]

## VERITAS Assessment
[2-3 sentence summary. If Integrity is negative, explicitly note: "This source is presenting [true/false] information using [dishonest/manipulative] methods."]

## Central Claims Analysis
- **Explicit claims:** [What the article directly states]
- **Implicit claims:** [What the article implies readers should believe]
- **What's omitted:** [Important context left out]

## Evidence Analysis
[Examine the evidence for/against the article's claims]

## Integrity Analysis
Evaluate the SOURCE'S honesty (not just whether claims are true):
- **Framing Choices:** [How does the article frame information? What's emphasized/minimized?]
- **Source Transparency:** [Does it acknowledge its perspective or present opinion as fact?]
- **Manipulation Markers:** [Cherry-picking, emotional manipulation, strawmanning, false balance?]
- **Who Benefits:** [What agenda or narrative does this framing serve?]

## Truth Distortion Patterns
[Identify specific techniques: selective framing, missing context, false equivalence, emotional manipulation, etc.]

## Integrity Concerns
[List specific epistemological red flags in the article's presentation]

## What We Can Be Confident About
[What is well-supported by evidence]

## What Remains Uncertain
[Open questions or areas needing more evidence]

## Bottom Line
[Clear statement addressing BOTH the truth of the claims AND the integrity of the source]

## Lessons for Information Assessment
[2-3 lessons about evaluating this type of content]

## Methodology Notes
[Explain your Reality Score and your Integrity Score separately. Why each rating?]

## Sources Referenced
[Comprehensive MLA 9th edition citations. 5-10 sources minimum.
Mark each: [CREDIBLE] / [QUESTIONABLE] / [PROBLEMATIC]
Prioritize peer-reviewed scholarship and primary sources.]

=== SCORING SCALES ===

REALITY SCORE (-10 to +10) — Is the CLAIM true?
+10: Definitively, verifiably true
+7 to +9: Strong evidence supports the claims
+4 to +6: Moderate evidence supports the claims
+1 to +3: Weak evidence supports the claims
0: Cannot determine / genuinely mixed evidence
-1 to -3: Weak evidence contradicts the claims
-4 to -6: Moderate evidence contradicts the claims  
-7 to -9: Strong evidence contradicts the claims
-10: Definitively, demonstrably false

INTEGRITY SCORE (-1.0 to +1.0) — Is the SOURCE honest?
+0.8 to +1.0: Excellent — Transparent, acknowledges limitations, fair framing
+0.5 to +0.7: Good — Minor issues, mostly intellectually honest
+0.1 to +0.4: Acceptable — Some embedded assumptions but not manipulative
0: Neutral — Neither helps nor hinders truth-seeking
-0.1 to -0.3: Concerning — Notable bias, spin, or hidden premises
-0.4 to -0.6: Problematic — Significant manipulation, selective presentation
-0.7 to -0.9: Dishonest — Propaganda techniques, bad-faith framing
-1.0: Deceptive — Fundamentally designed to mislead

=== KEY INSIGHT ===

A negative Integrity Score does NOT change the Reality Score.
It means: "Even if these facts are correct, this source is being dishonest about HOW it presents them."
This is crucial for media literacy — truth can be weaponized through manipulative framing."""


def get_question_inquiry_prompt(question):
    """Generate the assessment prompt for question mode with SEPARATE scores"""
    return f"""You are VERITAS, an evidence-based truth research system.

QUESTION: {question}

=== CRITICAL: TWO INDEPENDENT MEASUREMENTS ===

You must provide TWO SEPARATE scores that answer TWO DIFFERENT questions:

1. **REALITY SCORE** (-10 to +10): Is the CLAIM embedded in this question true or false?
   This measures correspondence with reality.

2. **INTEGRITY SCORE** (-1.0 to +1.0): Is the QUESTION framed honestly?
   This measures whether the question itself is epistemologically honest,
   regardless of whether its embedded claim is true.

THESE ARE INDEPENDENT. A question can ask about something:
- TRUE (+7) with HONEST framing (+0.8) — Legitimate inquiry
- TRUE (+7) with DISHONEST framing (-0.5) — Manipulative question about real phenomenon
- FALSE (-8) with HONEST framing (+0.6) — Good-faith question based on misconception
- FALSE (-8) with DISHONEST framing (-0.7) — Propaganda dressed as inquiry

DO NOT multiply these scores. Report them separately.

=== RESPONSE FORMAT ===

## CLAIM BEING TESTED
[First, explicitly state the testable claim embedded in this question.
Example: "Does D&D lead to Satanism?" → Claim: "Playing D&D causes people to become Satanists"
Example: "Were some slaves happy?" → Claim: "Slavery wasn't entirely bad because some enslaved people experienced happiness"]

# REALITY SCORE: [number from -10 to +10]
(Is the embedded CLAIM true or false? NOT whether the subject is "good" or "bad")

# INTEGRITY SCORE: [number from -1.0 to +1.0]  
(Is the QUESTION's framing honest or manipulative?)

## The Underlying Reality
[What is ACTUALLY TRUE about this subject?]

## VERITAS Assessment
[2-3 sentence summary. If Integrity is negative, explicitly note: "This question uses [dishonest/manipulative] framing to ask about something that is [true/false]."]

## Examining the Question's Framework
- **Hidden Premises:** What assumptions does this question smuggle in?
- **Ideological Origin:** What worldview does this framing come from? Who created it and why?
- **What's Being Obscured:** What context does this framing hide or minimize?
- **Reframing Needed:** How should this be asked for honest inquiry?

## Integrity Analysis
Rate the QUESTION's honesty (separate from whether its claim is true):
- **Framework Honesty:** Is this seeking truth or advancing an agenda?
- **Hidden Assumptions:** What must be accepted to engage with this question?
- **Manipulation Level:** [Honest / Naive / Misleading / Deliberately Deceptive]
- **Key Concerns:** Specific red flags

## The Central Claims (Explicit and Hidden)
- **Explicit claim:** What the question appears to ask
- **Hidden claims:** What the question assumes or implies
- **What the framing serves:** What agenda does this support?

## Evidence Analysis
[Evidence about the ACTUAL REALITY of the subject]

## Truth Distortion Patterns
[How does this FRAMING distort truth?]

## What We Can Be Confident About
[What evidence clearly supports]

## What Remains Uncertain
[Open questions]

## Bottom Line
[Clear statement revealing the truth AND exposing any framing problems]

## Lessons for Information Assessment
[2-3 lessons about recognizing this type of framing]

## Methodology Notes
[Explain your Reality Score and Integrity Score SEPARATELY. Why each rating?]

## Key Sources
[Comprehensive MLA 9th edition citations. 5-10 sources minimum.
Full publication details. Prioritize peer-reviewed scholarship and primary sources.]

=== SCORING SCALES ===

REALITY SCORE (-10 to +10) — Is the CLAIM true?
+10: The claim is definitively TRUE
+7 to +9: Strong evidence the claim IS true
+4 to +6: Moderate evidence the claim is true
+1 to +3: Weak evidence the claim is true
0: Genuinely uncertain / insufficient evidence
-1 to -3: Weak evidence the claim is FALSE
-4 to -6: Moderate evidence the claim is false
-7 to -9: Strong evidence the claim is FALSE
-10: The claim is definitively, demonstrably FALSE

INTEGRITY SCORE (-1.0 to +1.0) — Is the QUESTION honest?
+0.8 to +1.0: Excellent — Honest, neutral framing enabling truth-seeking
+0.5 to +0.7: Good — Minor issues, mostly honest
+0.1 to +0.4: Acceptable — Some assumptions but not manipulative
0: Neutral
-0.1 to -0.3: Concerning — Notable bias or hidden premises
-0.4 to -0.6: Problematic — Significant manipulation, loaded framing
-0.7 to -0.9: Dishonest — Bad-faith framing, propaganda techniques
-1.0: Deceptive — Pure manipulation dressed as inquiry

=== DETECTING DISHONEST FRAMING ===

A question MUST receive a NEGATIVE Integrity Score if it does ANY of these:

1. **REHABILITATES ATROCITY**: Normalizes or seeks silver linings in historical horrors
   Example: "Were some slaves happy?" → Integrity = -0.7 to -1.0

2. **"JUST ASKING QUESTIONS"**: Uses neutral-seeming inquiry to launder propaganda
   Example: "Did the Holocaust really kill 6 million?" → Integrity = -1.0

3. **FALSE PREMISE SMUGGLING**: Embeds false assumptions that must be accepted
   Example: "Why do vaccines cause autism?" → Integrity = -0.7 to -0.9

4. **VICTIM-BLAMING FRAMING**: Shifts focus from perpetrators to victims
   Example: "What were the women wearing?" → Integrity = -0.7 to -0.9

5. **BOTH-SIDES-ING SETTLED MATTERS**: Treats established facts as open questions
   Example: "Is climate change really happening?" → Integrity = -0.5 to -0.7

6. **MORAL PANIC FRAMING**: Repeats debunked fearmongering as open question
   Example: "Does D&D lead to Satanism?" → Integrity = -0.5 to -0.7

=== EXAMPLES ===

EXAMPLE 1: "Does D&D lead to Satanism?"
- Claim: "Playing D&D causes people to become Satanists"
- REALITY: Claim is FALSE — no evidence supports this → Reality Score: -8
- INTEGRITY: Question originates from debunked 1980s Satanic Panic → Integrity Score: -0.5
- These are reported SEPARATELY, not multiplied

EXAMPLE 2: "Is climate change caused by human activity?"
- Claim: "Human activity is causing climate change"
- REALITY: Claim is TRUE — overwhelming scientific consensus → Reality Score: +9
- INTEGRITY: Legitimate scientific question, honestly framed → Integrity Score: +0.8
- Both scores are high — good-faith inquiry about true phenomenon

EXAMPLE 3: Article reports true crime statistics but uses inflammatory framing
- REALITY: Statistics are accurate → Reality Score: +7
- INTEGRITY: Framing is designed to provoke fear, omits context → Integrity Score: -0.4
- Truth can be presented dishonestly

=== KEY INSIGHT ===

These scores answer DIFFERENT questions:
- Reality Score: "What is true?"
- Integrity Score: "Is this source/question operating honestly?"

A source can report TRUE facts DISHONESTLY.
A question can ask about FALSE claims HONESTLY.
Both dimensions matter for information literacy."""


# ============================================================
# ROUTES
# ============================================================

@app.route('/')
def index():
    """Serve the main page"""
    usage = load_usage()
    return render_template('index.html', 
                         usage_count=usage.get('count', 0),
                         usage_month=usage.get('month', ''))

@app.route('/api/config', methods=['GET', 'POST'])
def config():
    """Handle API key configuration"""
    if request.method == 'POST':
        data = request.json
        api_key = data.get('api_key', '')
        save_config(api_key)
        return jsonify({'success': True})
    else:
        api_key = load_config()
        usage = load_usage()
        return jsonify({
            'has_key': bool(api_key),
            'usage': usage
        })

@app.route('/api/assess', methods=['POST'])
def assess_article():
    """Assess an article"""
    data = request.json
    url = data.get('url', '')
    article_text = data.get('article_text', '')
    
    if not article_text:
        return jsonify({'error': 'No article text provided'}), 400
    
    api_key = load_config()
    if not api_key:
        return jsonify({'error': 'API key not configured. Click the settings button to add your key.'}), 401
    
    try:
        usage_count = increment_usage()
        
        client = anthropic.Anthropic(
            api_key=api_key,
            max_retries=0
        )
        prompt = get_article_assessment_prompt(url, article_text)
        
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        assessment = message.content[0].text
        
        return jsonify({
            'success': True,
            'assessment': assessment,
            'usage_count': usage_count,
            'source_url': url
        })
        
    except anthropic.AuthenticationError:
        return jsonify({'error': 'Invalid API key. Please check your settings.'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/inquire', methods=['POST'])
def inquire_question():
    """Research a question"""
    data = request.json
    question = data.get('question', '')
    
    if not question:
        return jsonify({'error': 'No question provided'}), 400
    
    api_key = load_config()
    if not api_key:
        return jsonify({'error': 'API key not configured. Click the settings button to add your key.'}), 401
    
    try:
        usage_count = increment_usage()
        
        client = anthropic.Anthropic(
            api_key=api_key,
            max_retries=0
        )
        prompt = get_question_inquiry_prompt(question)
        
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        assessment = message.content[0].text
        
        return jsonify({
            'success': True,
            'assessment': assessment,
            'usage_count': usage_count,
            'question': question
        })
        
    except anthropic.AuthenticationError:
        return jsonify({'error': 'Invalid API key. Please check your settings.'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_amplified_assessment_prompt(original_question, original_assessment):
    """Generate the amplified assessment prompt that enriches and challenges the initial assessment"""
    return f"""You are VERITAS Amplified Analysis - providing enriched perspective on an initial assessment.

ORIGINAL QUESTION/CLAIM: {original_question}

INITIAL ASSESSMENT:
{original_assessment}

=== YOUR ROLE ===

You are NOT adversarial. You are ENRICHING the analysis by:
1. Identifying potential blind spots or missing perspectives
2. Questioning assumptions that might be embedded
3. Highlighting areas where different frameworks might yield different conclusions
4. Acknowledging what evidence would change the assessment
5. Steelmanning alternative interpretations

This is intellectual partnership, not combat. The goal is BETTER REASONING, not winning arguments.

=== RESPONSE FORMAT ===

## Amplified Analysis Summary
[2-3 sentence overview of what this deeper analysis reveals]

## Key Challenges to Consider

### Challenge 1: [Name of challenge, e.g., "Source Selection Perspective"]
**The Question:** [What assumption or gap are we examining?]
**Why It Matters:** [How could this affect the assessment?]
**Consideration:** [What should we think about?]

### Challenge 2: [Name of challenge]
**The Question:** [What assumption or gap are we examining?]
**Why It Matters:** [How could this affect the assessment?]
**Consideration:** [What should we think about?]

### Challenge 3: [Name of challenge]
**The Question:** [What assumption or gap are we examining?]
**Why It Matters:** [How could this affect the assessment?]
**Consideration:** [What should we think about?]

[Continue with 4-7 total challenges]

## Missing Perspectives
[What viewpoints, frameworks, or evidence types weren't fully explored?]

## Alternative Framings
[How else might this question or claim be understood? What's the steelman version?]

## What Would Change This Assessment?
[Specific evidence or information that would shift the conclusions]

## Uncertainty Categorization
Review what the initial assessment listed as "uncertain":
- **Unknown (we don't know yet):** [List items]
- **Concerning (signals suggest potential issues):** [List items]  
- **Established (documented effects):** [List items]

## Epistemic Humility Check
"If I'm wrong about this assessment, it's most likely because..."
[Complete this sentence with 2-3 specific possibilities]

## Bottom Line
[Does this amplified analysis strengthen, weaken, or complicate the original assessment? Be specific.]

=== CRITICAL GUIDELINES ===

1. **Be Specific**: Don't say "sources might be biased" - identify WHICH sources and WHY that matters
2. **Quantify When Possible**: Don't say "partially" - ask "what percentage?" or "to what degree?"
3. **Distinguish Critique Types**: Separate "missing information" from "flawed reasoning" from "hidden assumptions"
4. **Stay Honest**: If the initial assessment is solid, say so. Amplification isn't about finding problems that don't exist.
5. **Focus on Substance**: Ignore minor stylistic issues. Focus on substantive analytical gaps.

Remember: You're helping VERITAS become more rigorous, not tearing down its work."""

@app.route('/api/amplify', methods=['POST'])
def amplify_assessment():
    """Generate amplified analysis of an initial assessment"""
    data = request.json
    original_question = data.get('question', '')
    original_assessment = data.get('assessment', '')
    
    if not original_assessment:
        return jsonify({'error': 'No assessment provided'}), 400
    
    api_key = load_config()
    if not api_key:
        return jsonify({'error': 'API key not configured'}), 401
    
    try:
        # Note: We don't increment usage for amplified analysis since it's part of the same assessment
        
        client = anthropic.Anthropic(
            api_key=api_key,
            max_retries=0
        )
        prompt = get_amplified_assessment_prompt(original_question, original_assessment)
        
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=3000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        amplified = message.content[0].text
        
        return jsonify({
            'success': True,
            'amplified': amplified
        })
        
    except anthropic.AuthenticationError:
        return jsonify({'error': 'Invalid API key'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("VERITAS Assessment Tool v2.8.1")
    print("Truth through Transparency")
    print("with Amplified Assessment")
    print("=" * 60)
    print("\nStarting server at http://localhost:5000")
    print("Press Ctrl+C to stop\n")
    app.run(debug=False, port=5000)
