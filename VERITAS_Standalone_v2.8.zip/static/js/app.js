// VERITAS v2.8 - JavaScript with Dual Independent Scoring System
// Reality Score + Integrity Score (no multiplication)

let currentMode = 'question';
let lastResult = null; // Store last result for save/export functions

// Mode Switching
function switchMode(mode) {
    currentMode = mode;
    
    const questionMode = document.getElementById('questionMode');
    const articleMode = document.getElementById('articleMode');
    const questionBtn = document.getElementById('questionModeBtn');
    const articleBtn = document.getElementById('articleModeBtn');
    
    if (mode === 'question') {
        questionMode.style.display = 'block';
        articleMode.style.display = 'none';
        questionBtn.classList.add('active');
        articleBtn.classList.remove('active');
    } else {
        questionMode.style.display = 'none';
        articleMode.style.display = 'block';
        questionBtn.classList.remove('active');
        articleBtn.classList.add('active');
    }
    
    document.getElementById('results').style.display = 'none';
    hideResultsActions(); // Hide action buttons when switching modes
}

// Perform Inquiry
async function performInquiry() {
    const loading = document.getElementById('loading');
    const results = document.getElementById('results');
    
    // Clear amplified cache for new assessment
    amplifiedCache = null;
    
    let endpoint, data;
    
    if (currentMode === 'question') {
        const question = document.getElementById('question').value.trim();
        if (!question) {
            alert('Please enter a question');
            return;
        }
        endpoint = '/api/inquire';
        data = { question };
    } else {
        const articleText = document.getElementById('articleText').value.trim();
        if (!articleText) {
            alert('Please enter article text');
            return;
        }
        const articleUrl = document.getElementById('articleUrl').value.trim();
        endpoint = '/api/assess';
        data = { url: articleUrl, article_text: articleText };
    }
    
    results.style.display = 'none';
    loading.style.display = 'block';
    
    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.error) {
            throw new Error(result.error);
        }
        
        document.getElementById('usageCount').textContent = result.usage_count;
        lastResult = result; // Store for save/export
        displayResults(result);
        
    } catch (error) {
        alert('Error: ' + error.message);
    } finally {
        loading.style.display = 'none';
    }
}

// Display Results with Independent Scores (Reality at top, Integrity in middle)
function displayResults(result) {
    const resultsDiv = document.getElementById('results');
    const assessment = result.assessment;
    
    // Extract the two independent scores
    const realityScore = extractRealityScore(assessment);
    const integrityScore = extractIntegrityScore(assessment);
    
    const sections = parseAssessment(assessment);
    
    let html = '<div class="assessment-result">';
    
    // Header with Reality Score only (like original)
    html += buildAssessmentHeader(realityScore, result);
    
    // Content
    html += '<div class="assessment-content">';
    
    // 1. Reality Score scale (colorful) at top
    html += buildScaleVisual(realityScore, 'Reality Score');
    
    // 2-13. Content sections in original order (Integrity section inserted at position 6)
    html += buildOrderedSections(sections, integrityScore, realityScore, assessment);
    
    html += '</div></div>';
    
    resultsDiv.innerHTML = html;
    resultsDiv.style.display = 'block';
    document.getElementById('resultsActions').style.display = 'flex'; // Show action buttons
    resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Build header with Reality Score (original style)
function buildAssessmentHeader(realityScore, result) {
    const color = getRatingColor(realityScore);
    const title = currentMode === 'question' ? result.question : 'Article Assessment';
    
    let html = '<div class="assessment-header">';
    html += '<div class="rating-container">';
    html += `<div class="rating-score" style="color: ${color};">${realityScore >= 0 ? '+' : ''}${realityScore}</div>`;
    html += '<div class="rating-logo"><img src="/static/images/veritas-logo.png" alt="VERITAS"></div>';
    html += '</div>';
    html += `<div class="assessment-title">${escapeHtml(title)}</div>`;
    html += '<div class="assessment-subtitle">Reality Score: Is the claim TRUE or FALSE?</div>';
    html += '</div>';
    
    return html;
}

// Build Scale Visual (original style)
function buildScaleVisual(score, label) {
    const position = ((score + 10) / 20) * 100;
    
    let html = '<div class="scale-visual">';
    html += `<div style="width: 100%; text-align: center; margin-bottom: 10px; font-weight: 600;">${label}: ${score >= 0 ? '+' : ''}${score}</div>`;
    html += '<div style="width: 100%;">';
    html += '<div class="scale-bar">';
    html += `<div class="scale-marker" style="left: ${Math.max(0, Math.min(100, position))}%;"></div>`;
    html += '</div>';
    html += '<div class="scale-labels">';
    html += '<span>-10<br><small>FALSE</small></span>';
    html += '<span>-5</span>';
    html += '<span>0<br><small>UNCERTAIN</small></span>';
    html += '<span>+5</span>';
    html += '<span>+10<br><small>TRUE</small></span>';
    html += '</div>';
    html += '</div></div>';
    
    return html;
}

// Build integrity warning flags
function buildIntegrityWarning(integrityScore, realityScore) {
    if (integrityScore >= -0.1) {
        return ''; // No warning needed
    }
    
    let warningClass, warningIcon, warningTitle, warningText;
    
    if (integrityScore >= -0.3) {
        warningClass = 'warning-caution';
        warningIcon = '⚠️';
        warningTitle = 'CAUTION: Some Bias Detected';
        warningText = `This ${currentMode === 'question' ? 'question' : 'source'} shows signs of bias or problematic framing. The ${realityScore >= 0 ? 'claims appear to be supported by evidence' : 'claims appear to contradict available evidence'}, but the presentation may be skewed.`;
    } else if (integrityScore >= -0.6) {
        warningClass = 'warning-alert';
        warningIcon = '🚨';
        warningTitle = 'WARNING: Significant Manipulation Detected';
        warningText = `This ${currentMode === 'question' ? 'question uses manipulative framing' : 'source demonstrates significant manipulation patterns'}. ${realityScore >= 0 ? 'While the core claims may be factually accurate' : 'The claims also appear to be inaccurate'}, the presentation is designed to mislead rather than inform.`;
    } else {
        warningClass = 'warning-danger';
        warningIcon = '🛑';
        warningTitle = 'ALERT: Deceptive Framing';
        warningText = `This ${currentMode === 'question' ? 'question' : 'source'} is operating deceptively. ${realityScore >= 0 ? 'Even if some facts are technically correct' : 'The claims are false, and'} the framing is fundamentally designed to manipulate rather than inform. Treat with extreme skepticism.`;
    }
    
    let html = `<div class="integrity-warning ${warningClass}">`;
    html += `<div class="warning-header">`;
    html += `<span class="warning-icon">${warningIcon}</span>`;
    html += `<span class="warning-title">${warningTitle}</span>`;
    html += `</div>`;
    html += `<div class="warning-text">${warningText}</div>`;
    html += `</div>`;
    
    return html;
}

// Build sections in the original order (EI at position 6)
function buildOrderedSections(sections, integrityScore, realityScore, assessment) {
    let html = '';
    
    // 2. The Underlying Truth / Reality
    let foundSection = findSection(sections, 'underlying truth');
    if (!foundSection) foundSection = findSection(sections, 'underlying reality');
    if (foundSection) {
        html += buildHighlightSection(foundSection.title, foundSection.content, 'highlight-box');
    }
    
    // 2b. VERITAS Assessment
    foundSection = findSection(sections, 'veritas assessment');
    if (foundSection) {
        html += buildHighlightSection(foundSection.title, foundSection.content, 'highlight-box');
    }
    
    // 3. Claim Being Tested (for questions)
    foundSection = findSection(sections, 'claim being tested');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 3b. Central Claims Analysis
    foundSection = findSection(sections, 'central claims');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 4. Evidence Analysis
    foundSection = findSection(sections, 'evidence analysis');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 5. Truth Distortion Patterns
    foundSection = findSection(sections, 'truth distortion');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 6. Integrity Score Section (with original teal EI gauge + warning flags)
    html += buildEISection(integrityScore, realityScore, assessment);
    
    // 7. Examining the Framework (Question or Article)
    foundSection = findSection(sections, 'examining the question');
    if (!foundSection) foundSection = findSection(sections, 'examining the article');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 7b. Integrity Analysis (text section from AI)
    foundSection = findSection(sections, 'integrity analysis');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 7c. Integrity Concerns
    foundSection = findSection(sections, 'integrity concerns');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 8. What We Can Be Confident About
    foundSection = findSection(sections, 'what we can be confident');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 9. What Remains Uncertain
    foundSection = findSection(sections, 'what remains uncertain');
    if (foundSection) {
        html += buildStandardSection(foundSection.title, foundSection.content);
    }
    
    // 10. Bottom Line
    foundSection = findSection(sections, 'bottom line');
    if (foundSection) {
        html += buildHighlightSection(foundSection.title, foundSection.content, 'highlight-box');
    }
    
    // 11. Lessons for Information Assessment
    foundSection = findSection(sections, 'lessons for information');
    if (foundSection) {
        html += buildLessonsSection(foundSection.title, foundSection.content);
    }
    
    // 12. Methodology Notes
    foundSection = findSection(sections, 'methodology notes');
    if (foundSection) {
        html += buildMethodologySection(foundSection.title, foundSection.content);
    }
    
    // 13. Key Sources / Sources Referenced
    foundSection = findSection(sections, 'key sources');
    if (!foundSection) foundSection = findSection(sections, 'sources referenced');
    if (foundSection) {
        html += buildSourcesSection(foundSection.title, foundSection.content);
    }
    
    // 14. VERITAS Amplified Assessment Section
    html += buildAmplifiedSection();
    
    return html;
}

// Build Amplified Assessment Section
function buildAmplifiedSection() {
    let html = '<div class="amplified-section">';
    html += '<div class="amplified-trigger">';
    html += '<button class="amplify-btn" id="amplifyBtn" onclick="requestAmplifiedAssessment()">🔎 VERITAS Amplified Assessment</button>';
    html += '<div class="amplify-loading" id="amplifyLoading" style="display: none;">';
    html += '<div class="spinner"></div>';
    html += '<p>Generating enriched analysis... This may take 20-30 seconds</p>';
    html += '</div>';
    html += '</div>';
    html += '<div class="amplified-analysis" id="amplifiedAnalysis" style="display: none;"></div>';
    html += '</div>';
    return html;
}

// Find a section by partial title match
function findSection(sections, titleFragment) {
    return sections.find(s => s.title.toLowerCase().includes(titleFragment.toLowerCase()));
}

// Build a standard section
function buildStandardSection(title, content) {
    let html = '<div class="section">';
    html += `<div class="section-title">${escapeHtml(title)}</div>`;
    html += '<div class="section-content">';
    html += formatContent(content);
    html += '</div></div>';
    return html;
}

// Build a highlight section
function buildHighlightSection(title, content, boxClass) {
    let html = `<div class="${boxClass}">`;
    html += `<strong>${escapeHtml(title)}</strong>`;
    html += formatContent(content);
    html += '</div>';
    return html;
}

// Build EI Section with original teal gauge + warning flags
function buildEISection(integrityScore, realityScore, assessment) {
    const eiClass = getIntegrityClass(integrityScore);
    const eiLabel = getIntegrityLabel(integrityScore);
    // Position: -1 is 0%, +1 is 100%
    const eiPosition = ((integrityScore + 1) / 2) * 100;
    
    // Extract EI details from assessment
    const eiDetails = extractEIDetails(assessment);
    
    let html = '<div class="ei-section">';
    html += '<div class="ei-header">';
    html += '<h4>📊 Integrity Score: Is the Source Operating Honestly?</h4>';
    html += `<span class="ei-score-badge ${eiClass}">${integrityScore >= 0 ? '+' : ''}${integrityScore.toFixed(2)} — ${eiLabel}</span>`;
    html += '</div>';
    
    // Warning flag if integrity is negative
    if (integrityScore < -0.1) {
        html += buildIntegrityWarning(integrityScore, realityScore);
    }
    
    // EI Scale - original teal gradient from -1 to +1
    html += '<div class="ei-scale">';
    html += `<div class="ei-marker" style="left: ${Math.max(0, Math.min(100, eiPosition))}%;"></div>`;
    html += '</div>';
    html += '<div class="ei-labels">';
    html += '<span>-1.0 Deceptive</span><span>-0.5 Dishonest</span><span>0 Neutral</span><span>+0.5 Good</span><span>+1.0 Honest</span>';
    html += '</div>';
    
    // EI Details - Framework focused
    if (Object.keys(eiDetails).length > 0) {
        html += '<div class="ei-details">';
        if (eiDetails.frameworkBias) {
            html += `<div class="ei-detail-item"><span class="ei-detail-label">Framework Bias</span><span class="ei-detail-value">${escapeHtml(eiDetails.frameworkBias)}</span></div>`;
        }
        if (eiDetails.hiddenAssumptions) {
            html += `<div class="ei-detail-item"><span class="ei-detail-label">Hidden Assumptions</span><span class="ei-detail-value">${escapeHtml(eiDetails.hiddenAssumptions)}</span></div>`;
        }
        if (eiDetails.frameworkTransparency) {
            html += `<div class="ei-detail-item"><span class="ei-detail-label">Framework Transparency</span><span class="ei-detail-value">${escapeHtml(eiDetails.frameworkTransparency)}</span></div>`;
        }
        if (eiDetails.manipulationMarkers) {
            html += `<div class="ei-detail-item"><span class="ei-detail-label">Manipulation Markers</span><span class="ei-detail-value">${escapeHtml(eiDetails.manipulationMarkers)}</span></div>`;
        }
        if (eiDetails.sourceTransparency) {
            html += `<div class="ei-detail-item"><span class="ei-detail-label">Source Transparency</span><span class="ei-detail-value">${escapeHtml(eiDetails.sourceTransparency)}</span></div>`;
        }
        html += '</div>';
    }
    
    html += '</div>';
    return html;
}

// Extract EI Details from assessment text
function extractEIDetails(assessment) {
    const details = {};
    
    const frameworkMatch = assessment.match(/\*\*Framework Bias:\*\*\s*([^\n*]+)/i);
    if (frameworkMatch) details.frameworkBias = frameworkMatch[1].trim();
    
    const hiddenMatch = assessment.match(/\*\*Hidden Assumptions:\*\*\s*([^\n*]+)/i);
    if (hiddenMatch) details.hiddenAssumptions = hiddenMatch[1].trim();
    
    const transparencyMatch = assessment.match(/\*\*(?:Framework |Source )?Transparency:\*\*\s*([^\n*]+)/i);
    if (transparencyMatch) details.frameworkTransparency = transparencyMatch[1].trim();
    
    const manipulationMatch = assessment.match(/\*\*Manipulation (?:Markers|Level):\*\*\s*([^\n*]+)/i);
    if (manipulationMatch) details.manipulationMarkers = manipulationMatch[1].trim();
    
    const sourceTransMatch = assessment.match(/\*\*Source Transparency:\*\*\s*([^\n*]+)/i);
    if (sourceTransMatch) details.sourceTransparency = sourceTransMatch[1].trim();
    
    return details;
}

// Build lessons section
function buildLessonsSection(title, content) {
    let html = '<div class="lessons-box">';
    html += `<strong>${escapeHtml(title)}</strong>`;
    html += '<div class="lessons-content">';
    html += formatLessonsContent(content);
    html += '</div></div>';
    return html;
}

// Format lessons content
function formatLessonsContent(content) {
    let html = '';
    const numberedPattern = /(\d+\.)\s*/g;
    const parts = content.split(numberedPattern).filter(p => p.trim());
    
    if (parts.length > 1) {
        html += '<ol class="lessons-list">';
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i].trim();
            if (!/^\d+\.$/.test(part)) {
                const headerMatch = part.match(/^\*\*(.+?)\*\*[:\s]*(.*)/s);
                if (headerMatch) {
                    html += `<li><strong>${escapeHtml(headerMatch[1])}</strong>`;
                    if (headerMatch[2]) {
                        html += `<p>${formatInline(headerMatch[2].trim())}</p>`;
                    }
                    html += '</li>';
                } else {
                    html += `<li>${formatInline(part)}</li>`;
                }
            }
        }
        html += '</ol>';
    } else {
        html += formatContent(content);
    }
    return html;
}

// Build methodology section
function buildMethodologySection(title, content) {
    let html = '<div class="methodology-note">';
    html += `<strong>${escapeHtml(title)}</strong>`;
    html += formatContent(content);
    html += '</div>';
    return html;
}

// Build sources section
function buildSourcesSection(title, content) {
    let html = '<div class="sources-section">';
    html += `<div class="section-title">${escapeHtml(title)}</div>`;
    html += '<div class="sources-content">';
    html += formatContent(content);
    html += '</div></div>';
    return html;
}

// Extract REALITY SCORE
function extractRealityScore(assessment) {
    let match = assessment.match(/REALITY SCORE:\s*([-+]?\d+(?:\.\d+)?)/i);
    if (!match) match = assessment.match(/RAW REALITY SCORE:\s*([-+]?\d+(?:\.\d+)?)/i);
    if (!match) match = assessment.match(/RAW TRUTH SCORE:\s*([-+]?\d+(?:\.\d+)?)/i);
    return match ? parseFloat(match[1]) : 0;
}

// Extract INTEGRITY SCORE
function extractIntegrityScore(assessment) {
    let match = assessment.match(/INTEGRITY SCORE:\s*([-+]?\d*\.?\d+)/i);
    if (!match) match = assessment.match(/EPISTEMOLOGICAL INTEGRITY[^:]*:\s*([-+]?\d*\.?\d+)/i);
    return match ? parseFloat(match[1]) : 0;
}

// Get Integrity CSS class
function getIntegrityClass(score) {
    if (score >= 0.5) return 'integrity-good';
    if (score >= 0) return 'integrity-neutral';
    if (score >= -0.3) return 'integrity-concerning';
    if (score >= -0.6) return 'integrity-problematic';
    return 'integrity-deceptive';
}

// Get Integrity Label
function getIntegrityLabel(score) {
    if (score >= 0.8) return 'Excellent';
    if (score >= 0.5) return 'Good';
    if (score >= 0.1) return 'Acceptable';
    if (score >= -0.1) return 'Neutral';
    if (score >= -0.3) return 'Concerning';
    if (score >= -0.6) return 'Problematic';
    if (score >= -0.9) return 'Dishonest';
    return 'Deceptive';
}

// Get Integrity Color
function getIntegrityColor(score) {
    if (score >= 0.5) return '#2e7d32';
    if (score >= 0) return '#689f38';
    if (score >= -0.3) return '#f9a825';
    if (score >= -0.6) return '#ef6c00';
    return '#c62828';
}

// Parse Assessment into Sections
function parseAssessment(assessment) {
    const sections = [];
    const parts = assessment.split(/^##\s+/m);
    
    for (let i = 1; i < parts.length; i++) {
        const lines = parts[i].split('\n');
        const title = lines[0].trim();
        const content = lines.slice(1).join('\n').trim();
        
        if (content) {
            sections.push({ title, content });
        }
    }
    
    return sections;
}

// Format Content
function formatContent(content) {
    let html = '';
    const paragraphs = content.split('\n\n');
    
    for (const para of paragraphs) {
        const trimmed = para.trim();
        if (!trimmed) continue;
        
        if (trimmed.match(/^[-*•]\s/m)) {
            html += '<ul>';
            const items = trimmed.split('\n').filter(line => line.match(/^[-*•]\s/));
            for (const item of items) {
                const text = item.replace(/^[-*•]\s/, '').trim();
                html += `<li>${formatInline(text)}</li>`;
            }
            html += '</ul>';
        } else {
            html += `<p>${formatInline(trimmed)}</p>`;
        }
    }
    
    return html;
}

// Format Inline
function formatInline(text) {
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    return escapeHtml(text).replace(/&lt;strong&gt;/g, '<strong>').replace(/&lt;\/strong&gt;/g, '</strong>');
}

// Get Rating Color (for Reality Score)
function getRatingColor(rating) {
    if (rating >= 9) return '#2e7d32';
    if (rating >= 7) return '#4caf50';
    if (rating >= 5) return '#8bc34a';
    if (rating >= 3) return '#cddc39';
    if (rating >= 1) return '#ffc107';
    if (rating >= -1) return '#ffc107';
    if (rating >= -3) return '#ff9800';
    if (rating >= -5) return '#ff5722';
    if (rating >= -7) return '#f44336';
    return '#d32f2f';
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Settings Modal
function openSettings() {
    document.getElementById('settingsModal').style.display = 'block';
    loadSettings();
}

function closeSettings() {
    document.getElementById('settingsModal').style.display = 'none';
}

async function loadSettings() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();
        if (config.has_key) {
            document.getElementById('apiKey').placeholder = '••••••••••••••••';
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

async function saveSettings() {
    const apiKey = document.getElementById('apiKey').value.trim();
    if (!apiKey) {
        alert('Please enter an API key');
        return;
    }
    
    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ api_key: apiKey })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('API key saved successfully!');
            closeSettings();
            document.getElementById('apiKey').value = '';
        }
    } catch (error) {
        alert('Error saving settings: ' + error.message);
    }
}

// About Modal
function openAbout() {
    document.getElementById('aboutModal').style.display = 'block';
}

function closeAbout() {
    document.getElementById('aboutModal').style.display = 'none';
}

// Close modals on outside click
window.onclick = function(event) {
    const settingsModal = document.getElementById('settingsModal');
    const aboutModal = document.getElementById('aboutModal');
    if (event.target == settingsModal) closeSettings();
    if (event.target == aboutModal) closeAbout();
}

// Check for API key on load
window.addEventListener('load', async function() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();
        if (!config.has_key) {
            setTimeout(() => {
                alert('Welcome to VERITAS v2.8! Please configure your Anthropic API key to get started.');
                openSettings();
            }, 500);
        }
    } catch (error) {
        console.error('Error checking config:', error);
    }
});

// ============================================
// SAVE, PRINT, AND EXPORT FUNCTIONS
// ============================================

// Generate filename based on assessment
function generateFilename(extension) {
    const date = new Date().toISOString().slice(0, 10);
    let subject = 'assessment';
    
    if (lastResult) {
        if (lastResult.question) {
            subject = lastResult.question.substring(0, 30)
                .replace(/[^a-zA-Z0-9\s]/g, '')
                .trim()
                .replace(/\s+/g, '_');
        } else if (lastResult.url) {
            subject = 'article';
        }
    }
    
    return `VERITAS_${subject}_${date}.${extension}`;
}

// Save as PDF using html2pdf.js
async function saveAsPDF() {
    const results = document.getElementById('results');
    if (!results || results.style.display === 'none') {
        alert('No results to save. Please run an assessment first.');
        return;
    }
    
    const btn = event.target.closest('.action-btn');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">Generating...</span>';
    
    try {
        const clone = results.cloneNode(true);
        clone.style.padding = '20px';
        
        const header = document.createElement('div');
        header.innerHTML = `
            <div style="text-align: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #4a9eff;">
                <h1 style="font-size: 28px; color: #1a1a2e; margin: 0;">VERITAS</h1>
                <p style="color: #4a9eff; margin: 5px 0;">Truth through Transparency</p>
                <p style="color: #999; font-size: 12px;">Assessment generated ${new Date().toLocaleDateString()}</p>
            </div>
        `;
        clone.insertBefore(header, clone.firstChild);
        
        const opt = {
            margin: [10, 10, 10, 10],
            filename: generateFilename('pdf'),
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2,
                useCORS: true,
                logging: false,
                letterRendering: true
            },
            jsPDF: { 
                unit: 'mm', 
                format: 'a4', 
                orientation: 'portrait' 
            },
            pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
        };
        
        await html2pdf().set(opt).from(clone).save();
        
    } catch (error) {
        console.error('Error generating PDF:', error);
        alert('Error generating PDF. Please try again.');
    } finally {
        btn.innerHTML = originalText;
    }
}

// Print Results
function printResults() {
    const results = document.getElementById('results');
    if (!results || results.style.display === 'none') {
        alert('No results to print. Please run an assessment first.');
        return;
    }
    window.print();
}

// Save Results as JSON
function saveResults() {
    if (!lastResult) {
        alert('No results to save. Please run an assessment first.');
        return;
    }
    
    const saveData = {
        version: 'VERITAS v2.8',
        timestamp: new Date().toISOString(),
        mode: currentMode,
        query: currentMode === 'question' ? lastResult.question : {
            url: lastResult.url || null,
            text: document.getElementById('articleText')?.value?.substring(0, 500) + '...' || null
        },
        scores: {
            reality: extractRealityScore(lastResult.assessment),
            integrity: extractIntegrityScore(lastResult.assessment)
        },
        fullAssessment: lastResult.assessment,
        usageCount: lastResult.usage_count
    };
    
    const blob = new Blob([JSON.stringify(saveData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = generateFilename('json');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Hide action buttons
function hideResultsActions() {
    const actions = document.getElementById('resultsActions');
    if (actions) {
        actions.style.display = 'none';
    }
}

// ============================================================
// AMPLIFIED ASSESSMENT FUNCTIONALITY
// ============================================================

let amplifiedCache = null; // Cache amplified analysis to avoid re-requesting

async function requestAmplifiedAssessment() {
    if (!lastResult || !lastResult.assessment) {
        alert('No assessment available to amplify');
        return;
    }
    
    const amplifyBtn = document.getElementById('amplifyBtn');
    const amplifyLoading = document.getElementById('amplifyLoading');
    const amplifiedSection = document.getElementById('amplifiedAnalysis');
    
    // If already loaded, just toggle visibility
    if (amplifiedCache) {
        toggleAmplifiedVisibility();
        return;
    }
    
    // Show loading state
    amplifyBtn.style.display = 'none';
    amplifyLoading.style.display = 'block';
    
    try {
        const response = await fetch('/api/amplify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question: lastResult.question || lastResult.source_url || 'Assessment',
                assessment: lastResult.assessment
            })
        });
        
        const result = await response.json();
        
        if (result.error) {
            throw new Error(result.error);
        }
        
        amplifiedCache = result.amplified;
        displayAmplifiedAnalysis(result.amplified);
        
    } catch (error) {
        alert('Error generating amplified analysis: ' + error.message);
        amplifyBtn.style.display = 'block';
    } finally {
        amplifyLoading.style.display = 'none';
    }
}

function displayAmplifiedAnalysis(amplified) {
    const amplifiedSection = document.getElementById('amplifiedAnalysis');
    const amplifyBtn = document.getElementById('amplifyBtn');
    
    // Parse the amplified content
    const sections = parseAmplifiedContent(amplified);
    
    let html = '<div class="amplified-content">';
    
    // Summary at top
    if (sections.summary) {
        html += '<div class="amplified-summary">';
        html += '<h3>🔍 Amplified Analysis Summary</h3>';
        html += `<p>${escapeHtml(sections.summary)}</p>`;
        html += '</div>';
    }
    
    // Key Challenges (always visible)
    if (sections.challenges && sections.challenges.length > 0) {
        html += '<div class="challenges-section">';
        html += '<h3>⚡ Key Challenges to Consider</h3>';
        sections.challenges.forEach((challenge, idx) => {
            html += '<div class="challenge-item">';
            html += `<h4>${challenge.title}</h4>`;
            if (challenge.question) html += `<p><strong>The Question:</strong> ${escapeHtml(challenge.question)}</p>`;
            if (challenge.matters) html += `<p><strong>Why It Matters:</strong> ${escapeHtml(challenge.matters)}</p>`;
            if (challenge.consideration) html += `<p><strong>Consideration:</strong> ${escapeHtml(challenge.consideration)}</p>`;
            html += '</div>';
        });
        html += '</div>';
    }
    
    // Expandable full analysis
    html += '<div class="full-analysis-toggle">';
    html += '<button class="expand-btn" onclick="toggleFullAnalysis()">📊 See Full Amplified Analysis</button>';
    html += '</div>';
    
    html += '<div class="full-analysis-content" id="fullAnalysisContent" style="display: none;">';
    
    // Rest of the sections
    if (sections.perspectives) {
        html += '<div class="analysis-section">';
        html += '<h3>🌐 Missing Perspectives</h3>';
        html += `<div>${formatMarkdown(sections.perspectives)}</div>`;
        html += '</div>';
    }
    
    if (sections.framings) {
        html += '<div class="analysis-section">';
        html += '<h3>🔄 Alternative Framings</h3>';
        html += `<div>${formatMarkdown(sections.framings)}</div>`;
        html += '</div>';
    }
    
    if (sections.change) {
        html += '<div class="analysis-section">';
        html += '<h3>🎯 What Would Change This Assessment?</h3>';
        html += `<div>${formatMarkdown(sections.change)}</div>`;
        html += '</div>';
    }
    
    if (sections.uncertainty) {
        html += '<div class="analysis-section">';
        html += '<h3>📊 Uncertainty Categorization</h3>';
        html += `<div>${formatMarkdown(sections.uncertainty)}</div>`;
        html += '</div>';
    }
    
    if (sections.humility) {
        html += '<div class="analysis-section">';
        html += '<h3>🤔 Epistemic Humility Check</h3>';
        html += `<div>${formatMarkdown(sections.humility)}</div>`;
        html += '</div>';
    }
    
    if (sections.bottom) {
        html += '<div class="analysis-section">';
        html += '<h3>✅ Bottom Line</h3>';
        html += `<div>${formatMarkdown(sections.bottom)}</div>`;
        html += '</div>';
    }
    
    html += '</div>'; // Close full-analysis-content
    html += '</div>'; // Close amplified-content
    
    amplifiedSection.innerHTML = html;
    amplifiedSection.style.display = 'block';
    amplifyBtn.textContent = '🔼 Hide Amplified Analysis';
    amplifyBtn.onclick = toggleAmplifiedVisibility;
    amplifyBtn.style.display = 'block';
}

function parseAmplifiedContent(content) {
    const sections = {};
    
    // Extract summary
    const summaryMatch = content.match(/##\s*Amplified Analysis Summary\s*([\s\S]*?)(?=##|$)/i);
    if (summaryMatch) sections.summary = summaryMatch[1].trim();
    
    // Extract challenges
    const challengesMatch = content.match(/##\s*Key Challenges to Consider\s*([\s\S]*?)(?=##[^#]|$)/i);
    if (challengesMatch) {
        const challengeText = challengesMatch[1];
        const challengePattern = /###\s*Challenge\s*\d+:\s*(.*?)\n([\s\S]*?)(?=###|##|$)/gi;
        sections.challenges = [];
        let match;
        while ((match = challengePattern.exec(challengeText)) !== null) {
            const challenge = { title: match[1].trim() };
            const content = match[2];
            
            const questionMatch = content.match(/\*\*The Question:\*\*\s*(.*?)(?=\*\*|$)/i);
            if (questionMatch) challenge.question = questionMatch[1].trim();
            
            const mattersMatch = content.match(/\*\*Why It Matters:\*\*\s*(.*?)(?=\*\*|$)/i);
            if (mattersMatch) challenge.matters = mattersMatch[1].trim();
            
            const considerMatch = content.match(/\*\*Consideration:\*\*\s*(.*?)(?=\*\*|$)/i);
            if (considerMatch) challenge.consideration = considerMatch[1].trim();
            
            sections.challenges.push(challenge);
        }
    }
    
    // Extract other sections
    const perspectivesMatch = content.match(/##\s*Missing Perspectives\s*([\s\S]*?)(?=##|$)/i);
    if (perspectivesMatch) sections.perspectives = perspectivesMatch[1].trim();
    
    const framingsMatch = content.match(/##\s*Alternative Framings\s*([\s\S]*?)(?=##|$)/i);
    if (framingsMatch) sections.framings = framingsMatch[1].trim();
    
    const changeMatch = content.match(/##\s*What Would Change This Assessment\?\s*([\s\S]*?)(?=##|$)/i);
    if (changeMatch) sections.change = changeMatch[1].trim();
    
    const uncertaintyMatch = content.match(/##\s*Uncertainty Categorization\s*([\s\S]*?)(?=##|$)/i);
    if (uncertaintyMatch) sections.uncertainty = uncertaintyMatch[1].trim();
    
    const humilityMatch = content.match(/##\s*Epistemic Humility Check\s*([\s\S]*?)(?=##|$)/i);
    if (humilityMatch) sections.humility = humilityMatch[1].trim();
    
    const bottomMatch = content.match(/##\s*Bottom Line\s*([\s\S]*?)(?=##|$)/i);
    if (bottomMatch) sections.bottom = bottomMatch[1].trim();
    
    return sections;
}

function toggleAmplifiedVisibility() {
    const amplifiedSection = document.getElementById('amplifiedAnalysis');
    const amplifyBtn = document.getElementById('amplifyBtn');
    
    if (amplifiedSection.style.display === 'none') {
        amplifiedSection.style.display = 'block';
        amplifyBtn.textContent = '🔼 Hide Amplified Analysis';
    } else {
        amplifiedSection.style.display = 'none';
        amplifyBtn.textContent = '🔎 VERITAS Amplified Assessment';
    }
}

function toggleFullAnalysis() {
    const fullContent = document.getElementById('fullAnalysisContent');
    const toggleBtn = event.target;
    
    if (fullContent.style.display === 'none') {
        fullContent.style.display = 'block';
        toggleBtn.textContent = '🔼 Hide Full Analysis';
    } else {
        fullContent.style.display = 'none';
        toggleBtn.textContent = '📊 See Full Amplified Analysis';
    }
}

function formatMarkdown(text) {
    // Basic markdown formatting
    return text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/^- (.*)$/gm, '<li>$1</li>')
        .replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/^(?!<)(.+)$/gm, '<p>$1</p>');
}
